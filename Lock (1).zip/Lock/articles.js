// Add one entry per article. Dates use YYYY-MM-DD.
// URLs are relative to the Lock folder.
window.LOCK_ARTICLES = [
    {
        title: "Welcome to The Lock Corner",
        date: "2026-11-05",
        description: "Notes and research on physical security.",
        keywords: ["physical security", "research"],
        url: "article/welcome.html"
    }
];
