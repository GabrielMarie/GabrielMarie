THE LOCK CORNER

Copier Lock dans le dossier publie par GitHub Pages.
Ouvrir index.html pour verifier le site localement.

Ajouter un article :
1. Dupliquer article/welcome.html et modifier son contenu.
2. Ajouter son titre, sa date YYYY-MM-DD, sa description,
   ses mots-cles et son chemin dans articles.js.

La recherche porte sur les titres, descriptions et mots-cles.
La liste et la recherche necessitent JavaScript.
La police Google Fonts necessite Internet (sinon monospace).

Contact : adresse configuree. URL LinkedIn a fournir.
Le dossier Lock ne constitue pas une protection d'acces.
